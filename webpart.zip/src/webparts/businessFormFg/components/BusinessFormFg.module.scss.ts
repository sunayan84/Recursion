/* tslint:disable */
require("./BusinessFormFg.module.css");
const styles = {
  businessFormFg: 'businessFormFg_ac5ed37b',
  container: 'container_ac5ed37b',
  row: 'row_ac5ed37b',
  column: 'column_ac5ed37b',
  'ms-Grid': 'ms-Grid_ac5ed37b',
  title: 'title_ac5ed37b',
  subTitle: 'subTitle_ac5ed37b',
  description: 'description_ac5ed37b',
  button: 'button_ac5ed37b',
  label: 'label_ac5ed37b',
  classMainTable: 'classMainTable_ac5ed37b',
  headingRow: 'headingRow_ac5ed37b',
  headingText: 'headingText_ac5ed37b',
  headerInput: 'headerInput_ac5ed37b',
  normalHeaderText: 'normalHeaderText_ac5ed37b',
  normalHeaderInput: 'normalHeaderInput_ac5ed37b',
  normalGap: 'normalGap_ac5ed37b',
  normalHeading: 'normalHeading_ac5ed37b',
  tdStakeHolder: 'tdStakeHolder_ac5ed37b',
  normalSubHeading: 'normalSubHeading_ac5ed37b',
  tdScope: 'tdScope_ac5ed37b',
  tdMilesStones: 'tdMilesStones_ac5ed37b'
};

export default styles;
/* tslint:enable */