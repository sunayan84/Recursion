declare interface IBusinessFormFgWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BusinessFormFgWebPartStrings' {
  const strings: IBusinessFormFgWebPartStrings;
  export = strings;
}
