declare const styles: {
    clickStopNavBar: string;
    navBarItems: string;
    mobilePreviewDeviceTitle: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewClickStopBar.module.scss.d.ts.map