declare const styles: {
    mobilePreviewDevice: string;
    mobilePreviewPortrait: string;
    mobilePreviewLandscape: string;
    mobilePreviewTablet: string;
    mobilePreviewIframe: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewDeviceView.module.scss.d.ts.map