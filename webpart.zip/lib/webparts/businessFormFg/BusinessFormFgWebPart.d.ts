import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IBusinessFormFgWebPartProps {
    description: string;
    context: WebPartContext;
}
export default class BusinessFormFgWebPart extends BaseClientSideWebPart<IBusinessFormFgWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=BusinessFormFgWebPart.d.ts.map