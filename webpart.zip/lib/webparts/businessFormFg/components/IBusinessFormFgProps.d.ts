import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IBusinessFormFgProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IBusinessFormFgProps.d.ts.map