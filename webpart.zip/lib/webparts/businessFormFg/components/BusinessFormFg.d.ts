import * as React from 'react';
import { IBusinessFormFgProps } from './IBusinessFormFgProps';
export default class BusinessFormFg extends React.Component<IBusinessFormFgProps, {}> {
    render(): React.ReactElement<IBusinessFormFgProps>;
    private _getPeoplePickerItems;
}
//# sourceMappingURL=BusinessFormFg.d.ts.map