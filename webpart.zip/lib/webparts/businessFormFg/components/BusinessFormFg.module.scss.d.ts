declare const styles: {
    businessFormFg: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    classMainTable: string;
    headingRow: string;
    headingText: string;
    headerInput: string;
    normalHeaderText: string;
    normalHeaderInput: string;
    normalGap: string;
    normalHeading: string;
    tdStakeHolder: string;
    normalSubHeading: string;
    tdScope: string;
    tdMilesStones: string;
};
export default styles;
//# sourceMappingURL=BusinessFormFg.module.scss.d.ts.map